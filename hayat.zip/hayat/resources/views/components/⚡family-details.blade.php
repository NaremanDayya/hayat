<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    {{-- Simplicity is the ultimate sophistication. - Leonardo da Vinci --}}
</div>