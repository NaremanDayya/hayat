<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    {{-- Walk as if you are kissing the Earth with your feet. - Thich Nhat Hanh --}}
</div>