<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    {{-- Simplicity is an acquired taste. - Katharine Gerould --}}
</div>