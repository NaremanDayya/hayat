<div style="display: flex; justify-content: center; align-items: center; min-height: 70vh;">
    <div class="card" style="width: 400px;">
        <h2 style="text-align: center; margin-bottom: 20px;">تسجيل الدخول للنظام</h2>
        
        <form wire:submit.prevent="login">
            <div>
                <label>البريد الإلكتروني</label>
                <input type="email" wire:model="email" placeholder="admin@hayat.com">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: #e74c3c; font-size: 0.8rem;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div style="margin-top: 15px;">
                <label>كلمة المرور</label>
                <input type="password" wire:model="password">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: #e74c3c; font-size: 0.8rem;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 25px; padding: 12px;">دخول</button>
        </form>
        
        <p style="text-align: center; margin-top: 20px; color: #666; font-size: 0.9rem;">
            استخدم البيانات المسجلة في السيرفر للدخول
        </p>
    </div>
</div>
<?php /**PATH D:\laragon\www\hayat\resources\views/livewire/login.blade.php ENDPATH**/ ?>