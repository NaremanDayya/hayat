<div class="card">
    <div class="flex-between" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3>بيانات الأبناء الذكور</h3>
        <div style="display: flex; gap: 10px; align-items: center;">
            <input type="text" wire:model.live.debounce.300ms="search" placeholder="بحث في الاسم أو الهوية..." style="width: 300px;">
            
            <button wire:click="resetFilters" class="btn" style="background: #95a5a6; color: white;">مسح الفلاتر</button>
            <button wire:click="exportExcel" class="btn" style="background: #27ae60; color: white;">تصدير Excel</button>
            <div style="position: relative;" x-data="{ open: false }">
                <button @click="open = !open" class="btn btn-primary">فلترة العمر</button>
                <div x-show="open" @click.away="open = false" class="card" style="position: absolute; top: 100%; left: 0; z-index: 100; width: 250px; background: white; margin-top: 10px;">
                    <label>العمر:</label>
                    <input type="number" wire:model.live="filterAge" placeholder="العمر">
                    <label style="margin-top:10px; display:block;">الحالة:</label>
                    <select wire:model.live="ageCondition">
                        <option value=">=">أكبر من أو يساوي</option>
                        <option value="<=">أصغر من أو يساوي</option>
                        <option value="=">بالضبط</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>الاسم</th>
                    <th>رقم الهوية</th>
                    <th>تاريخ الميلاد</th>
                    <th>العمر</th>
                    <th>اسم الأب</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $sons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $son): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <tr>
                    <td><?php echo e($son->name); ?></td>
                    <td><?php echo e($son->id_number); ?></td>
                    <td><?php echo e($son->dob); ?></td>
                    <td><?php echo e($son->age); ?></td>
                    <td><?php echo e($son->family->husband_name); ?></td>
                    <td>
                        <a href="/family/<?php echo e($son->family_id); ?>" class="btn btn-primary">عرض العائلة</a>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 20px;">
        <?php echo e($sons->links()); ?>

    </div>
</div>
<?php /**PATH D:\laragon\www\hayat\resources\views/livewire/son-list.blade.php ENDPATH**/ ?>