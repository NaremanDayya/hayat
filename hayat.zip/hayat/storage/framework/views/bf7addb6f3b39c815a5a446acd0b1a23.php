<div>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--accent); padding-bottom: 10px; margin-bottom: 30px;">
        <h2>تفاصيل عائلة: <?php echo e($family->husband_name); ?></h2>
        <a href="/families" class="btn btn-secondary" style="background: #34495e; color: white;">رجوع للقائمة</a>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
        <!-- Parents Information -->
        <div class="card" style="background: #fff;">
            <h3>بيانات الوالدين</h3>
            <table class="details-table">
                <tr>
                    <td style="font-weight: bold; width: 40%;">اسم الزوج:</td>
                    <td><?php echo e($family->husband_name); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">رقم هوية الزوج:</td>
                    <td><?php echo e($family->husband_id_number); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">تاريخ ميلاد الزوج:</td>
                    <td><?php echo e($family->husband_dob); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">هاتف الزوج:</td>
                    <td><?php echo e($family->husband_phone); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">الحالة الاجتماعية:</td>
                    <td><span class="badge" style="background: #3498db; color: white;"><?php echo e($family->marital_status); ?></span></td>
                </tr>
                <tr style="border-top: 2px solid #eee;">
                    <td style="font-weight: bold;">اسم الزوجة:</td>
                    <td><?php echo e($family->wife_name); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">رقم هوية الزوجة:</td>
                    <td><?php echo e($family->wife_id_number); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">تاريخ ميلاد الزوجة:</td>
                    <td><?php echo e($family->wife_dob); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold;">هاتف الزوجة:</td>
                    <td><?php echo e($family->wife_phone); ?></td>
                </tr>
            </table>
        </div>

        <!-- Residence and Stats -->
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div class="card" style="background: #fff; flex: 1;">
                <h3>بيانات السكن</h3>
                <p><strong>السكن الأصلي:</strong> <?php echo e($family->original_address); ?></p>
                <p><strong>السكن الحالي:</strong> <?php echo e($family->current_address); ?></p>
            </div>
            <div class="card" style="background: var(--accent); color: white; flex: 1; text-align: center;">
                <h3>إجمالي عدد الأفراد</h3>
                <div style="font-size: 3rem; font-weight: bold;"><?php echo e($family->family_members_count); ?></div>
            </div>
        </div>
    </div>

    <!-- Children Sections -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 30px;">
        <div class="card" style="border-top: 5px solid #3498db;">
            <h3>الأبناء الذكور</h3>
            <table>
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>رقم الهوية</th>
                        <th>العمر</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $family->members->where('gender', 'male'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $son): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($son->name); ?></td>
                        <td><?php echo e($son->id_number); ?></td>
                        <td><?php echo e($son->age); ?></td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="card" style="border-top: 5px solid #e91e63;">
            <h3>الأبناء الإناث</h3>
            <table>
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>رقم الهوية</th>
                        <th>العمر</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $family->members->where('gender', 'female'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daughter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($daughter->name); ?></td>
                        <td><?php echo e($daughter->id_number); ?></td>
                        <td><?php echo e($daughter->age); ?></td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Health Conditions -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($family->healthConditions->count() > 0): ?>
    <div class="card" style="margin-top: 30px; border: 2px solid #e74c3c;">
        <h3 style="color: #e74c3c;">الحالات الصحية والخاصة</h3>
        <table>
            <thead>
                <tr>
                    <th>اسم الشخص</th>
                    <th>طبيعة الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $family->family_health_conditions ?? $family->healthConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <tr>
                    <td><?php echo e($condition->person_name); ?></td>
                    <td><?php echo e($condition->condition_details); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<style>
    .details-table td {
        padding: 10px;
        border-bottom: none;
    }
</style>
</div>
<?php /**PATH D:\laragon\www\hayat\resources\views/livewire/family-details.blade.php ENDPATH**/ ?>